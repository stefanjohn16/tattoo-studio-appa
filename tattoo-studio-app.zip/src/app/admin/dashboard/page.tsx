"use client";

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

export default function AdminDashboard() {
  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">Admin Dashboard</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle>Artists</CardTitle>
            <CardDescription>Manage tattoo artists</CardDescription>
          </CardHeader>
          <CardContent>
            <p>Add, edit, or remove artists and their services.</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle>Services</CardTitle>
            <CardDescription>Manage available services</CardDescription>
          </CardHeader>
          <CardContent>
            <p>Configure services offered by each artist.</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle>Bookings</CardTitle>
            <CardDescription>Manage client bookings</CardDescription>
          </CardHeader>
          <CardContent>
            <p>Create new bookings and manage existing appointments.</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle>Block Time</CardTitle>
            <CardDescription>Manage unavailable time slots</CardDescription>
          </CardHeader>
          <CardContent>
            <p>Block specific dates and times for holidays or maintenance.</p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
