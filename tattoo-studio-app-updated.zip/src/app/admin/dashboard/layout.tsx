"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

export default function AdminDashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const router = useRouter();
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Check if user is authenticated
    const adminAuthenticated = sessionStorage.getItem("adminAuthenticated");
    
    if (adminAuthenticated !== "true") {
      // Redirect to login page if not authenticated
      router.push("/admin/login");
    } else {
      setIsAuthenticated(true);
    }
    
    setIsLoading(false);
  }, [router]);

  const handleLogout = () => {
    // Clear authentication state
    sessionStorage.removeItem("adminAuthenticated");
    // Redirect to login page
    router.push("/admin/login");
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-100">
        <p>Loading...</p>
      </div>
    );
  }

  if (!isAuthenticated) {
    return null; // Will redirect in useEffect
  }

  return (
    <div className="min-h-screen bg-slate-100">
      <header className="bg-slate-900 text-white py-4 px-6">
        <div className="container mx-auto flex justify-between items-center">
          <h1 className="text-xl font-bold">Tattoo Studio Admin</h1>
          <Button variant="outline" className="border-white text-white hover:bg-white hover:text-slate-900" onClick={handleLogout}>
            Logout
          </Button>
        </div>
      </header>

      <div className="container mx-auto py-8 px-4">
        <div className="grid grid-cols-1 md:grid-cols-[250px_1fr] gap-8">
          {/* Sidebar Navigation */}
          <aside className="space-y-4">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-lg">Navigation</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2 pt-0">
                <Button 
                  variant="ghost" 
                  className="w-full justify-start" 
                  onClick={() => router.push("/admin/dashboard")}
                >
                  Dashboard
                </Button>
                <Button 
                  variant="ghost" 
                  className="w-full justify-start" 
                  onClick={() => router.push("/admin/dashboard/artists")}
                >
                  Artists
                </Button>
                <Button 
                  variant="ghost" 
                  className="w-full justify-start" 
                  onClick={() => router.push("/admin/dashboard/services")}
                >
                  Services
                </Button>
                <Button 
                  variant="ghost" 
                  className="w-full justify-start" 
                  onClick={() => router.push("/admin/dashboard/bookings")}
                >
                  Bookings
                </Button>
                <Button 
                  variant="ghost" 
                  className="w-full justify-start" 
                  onClick={() => router.push("/admin/dashboard/block-time")}
                >
                  Block Time
                </Button>
              </CardContent>
            </Card>
          </aside>

          {/* Main Content */}
          <main>
            {children}
          </main>
        </div>
      </div>
    </div>
  );
}
