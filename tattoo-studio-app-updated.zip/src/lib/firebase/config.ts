// src/lib/firebase/config.ts
// Firebase configuration

export const firebaseConfig = {
  apiKey: "AIzaSyCs-Vj2ATrZCLuu_w11I4lGa2FEtJXmXx4",
  authDomain: "local-booking-7a055.firebaseapp.com",
  projectId: "local-booking-7a055",
  storageBucket: "local-booking-7a055.firebasestorage.app",
  messagingSenderId: "193767326202",
  appId: "1:193767326202:web:55c80e547a135c44b3e443"
};
